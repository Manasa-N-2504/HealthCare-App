import React from "react"; // Importing the React library
import BannerImage from "../assets/contact.png"; // Importing the background image
import "../styles/Contact.css"; // Importing a CSS file for styling

function Contact() {
  return (
    <div className="contact"> {/* Container for the entire Contact component */}
      <div
        className="leftSide"
        style={{ backgroundImage: `url(${BannerImage})` }} // Setting the background image
      ></div> {/* Left side with the background image */}
      <div className="rightSide"> {/* Right side containing contact form */}
        <h1> Contact Us For Queries </h1> {/* Heading */}
        {/* Contact form */}
        <form id="contact-form" method="POST">
          <label htmlFor="name">Full Name</label>
          <input name="name" placeholder="Enter full name..." type="text" /> {/* Input field for full name */}
          <label htmlFor="email">Email</label>
          <input name="email" placeholder="Enter email..." type="email" /> {/* Input field for email */}
          <label htmlFor="message">Query</label>
          <textarea
            rows="6"
            placeholder="Enter Query..."
            name="message"
            required
          ></textarea> {/* Textarea for entering the query */}
          <button type="submit"> Send Message</button> {/* Submit button */}
        </form>
      </div>
    </div>
  );
}

export default Contact; // Exporting the Contact component as the default export
