import React from "react"; // Importing the React library
import { Link } from "react-router-dom"; // Importing the Link component from react-router-dom
import BannerImage from "../assets/home.jpeg"; // Importing the background image
import "../styles/Home.css"; // Importing a CSS file for styling

function Home() {
  return (
    <div className="home"> {/* Container for the entire Home component */}
      {/* Background image */}
      <div className="headerContainer"
        style={{ backgroundImage: `url(${BannerImage})` }} // Setting the background image
      >
        <h1>MAX HEALTHCARE</h1> {/* Main heading */}
        <h2>QUALITY HEALTHCARE HOSPITAL</h2> {/* Subheading */}
        <p>YOUR HEALTH, OUR PRIORITY</p> {/* Slogan */}
        <Link to="/appointment">
          <button>BOOK APPOINTMENT</button> {/* Button to navigate to the appointment page */}
        </Link>
      </div>
    </div>
  );
}

export default Home; // Exporting the Home component as the default export
