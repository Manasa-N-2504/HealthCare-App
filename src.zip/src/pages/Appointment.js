import React, { useState } from "react"; // Importing React and the useState hook
import BannerImage from "../assets/appointment.jpg"; // Importing the background image
import "../styles/Appointment.css"; // Importing a CSS file for styling

function Appointment() {
  // State variable to track whether an appointment is booked
  const [isBooked, setIsBooked] = useState(false);

  // Function to handle booking an appointment
  const handleBookAppointment = () => {
    setIsBooked(true);
  };

  return (
    <div className="appointment-container"> {/* Container for the entire Appointment component */}
      {/* Background image */}
      <div
        className="appointment-content"
        style={{ backgroundImage: `url(${BannerImage})` }} // Setting the background image
      >
        <div className="appointment-header">
          SCHEDULE YOUR APPOINTMENT ONLINE {/* Header */}
        </div>
        <div className="input-group">
          <input type="text" placeholder="SPECIALIZATION" /> {/* Input field for specialization */}
          <input type="text" placeholder="DOCTOR NAME" /> {/* Input field for doctor name */}
          <input type="text" placeholder="LOCATION" /> {/* Input field for location */}
        </div>
        <button className="book-button" onClick={handleBookAppointment}>
          BOOK NOW {/* Button to book the appointment */}
        </button>
        {/* Container that displays when an appointment is booked */}
        <div className={`prompt-container ${isBooked ? "active" : ""}`}>
          <p>APPOINTMENT BOOKED!!</p>
          <p>THANK YOU</p>
        </div>
      </div>
    </div>
  );
}

export default Appointment; // Exporting the Appointment component as the default export
