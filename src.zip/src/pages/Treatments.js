import React, { useState } from "react"; // Importing React and the useState hook
import treatmentBackground from "../assets/treatment.png"; // Importing the background image
import "../styles/Treatments.css"; // Importing a CSS file for styling

// Array of objects containing information about medical specialities
const specialities = [
  {
    name: "NEUROLOGY",
    brief: [
      "ABOUT THE DEPARTMENT: SPECIALIZES IN DIAGNOSING AND TREATING DISORDERS OF THE NERVOUS SYSTEM, INCLUDING BRAIN, SPINAL CORD, AND NERVE CONDITIONS.",
      "GOAL OR MAIN AIM: TO PROVIDE EXPERT CARE FOR NEUROLOGICAL CONDITIONS, IMPROVING PATIENTS' QUALITY OF LIFE AND FUNCTIONING.",
      "MAJOR SURGERIES: BRAIN TUMOR RESECTION, DEEP BRAIN STIMULATION, ANEURYSM CLIPPING/COILING, SPINAL FUSION, EPILEPSY SURGERY."
    ],
  },
  {
    name: "THORACIC SURGERY",
    brief: [
      "ABOUT THE DEPARTMENT: SPECIALIZES IN SURGICAL TREATMENTS FOR CHEST, LUNG, AND ESOPHAGEAL CONDITIONS.",
      "GOAL OR MAIN AIM: TO PROVIDE PATIENTS WITH ADVANCED TREATMENTS FOR THORACIC DISORDERS, IMPROVING RESPIRATORY FUNCTION AND QUALITY OF LIFE.",
      "MAJOR SURGERIES: LUNG RESECTION, MEDIASTINOSCOPY, ESOPHAGECTOMY, THYMECTOMY, LOBECTOMY."
    ],
  },
  {
    name: "CARDIOLOGY",
    brief: [
      "ABOUT THE DEPARTMENT: FOCUSES ON DIAGNOSING AND TREATING HEART AND CARDIOVASCULAR CONDITIONS.",
      "GOAL OR MAIN AIM: TO IMPROVE HEART HEALTH AND FUNCTION THROUGH ADVANCED DIAGNOSTICS, TREATMENTS, AND PREVENTIVE STRATEGIES.",
      "MAJOR SURGERIES: ANGIOPLASTY (PCI), HEART BYPASS SURGERY, CARDIAC CATHETERIZATION, HEART VALVE REPLACEMENT, PACEMAKER IMPLANTATION."
    ],
  },
  {
    name: "PULMONOLOGY",
    brief: [
      "ABOUT THE DEPARTMENT: SPECIALIZES IN DIAGNOSING AND TREATING RESPIRATORY AND LUNG CONDITIONS.",
      "GOAL OR MAIN AIM: TO ENHANCE BREATHING AND RESPIRATORY FUNCTION, PROVIDING PATIENTS WITH EFFECTIVE TREATMENTS FOR LUNG DISORDERS.",
      "MAJOR SURGERIES: LUNG RESECTION, BRONCHOSCOPY, THORACENTESIS, SLEEP STUDY, LUNG TRANSPLANT."
    ],
  },
  {
    name: "ORTHOPAEDICS",
    brief: [
      "ABOUT THE DEPARTMENT: FOCUSES ON DIAGNOSING AND TREATING MUSCULOSKELETAL CONDITIONS, INCLUDING BONE, JOINT, AND SPINE DISORDERS.",
      "GOAL OR MAIN AIM: TO IMPROVE MOBILITY, FUNCTION, AND QUALITY OF LIFE THROUGH SURGICAL AND NON-SURGICAL INTERVENTIONS.",
      "MAJOR SURGERIES: JOINT REPLACEMENT, SPINAL SURGERY, FRACTURE FIXATION, SPORTS INJURY SURGERY, HAND SURGERY."
    ],
  },
  {
    name: "ONCOLOGY",
    brief: [
      "ABOUT THE DEPARTMENT: SPECIALIZES IN DIAGNOSING AND TREATING CANCER, INCLUDING MEDICAL, SURGICAL, AND RADIATION THERAPIES.",
      "GOAL OR MAIN AIM: TO PROVIDE COMPREHENSIVE CANCER CARE, AIMING FOR EARLY DETECTION, EFFECTIVE TREATMENT, AND IMPROVED QUALITY OF LIFE.",
      "MAJOR SURGERIES: TUMOR REMOVAL, CHEMOTHERAPY, RADIATION THERAPY, STEM CELL TRANSPLANT, PRECISION MEDICINE."
    ],
  },
  {
    name: "OPHTHALMOLOGY",
    brief: [
      "ABOUT THE DEPARTMENT: FOCUSES ON DIAGNOSING AND TREATING EYE CONDITIONS AND DISEASES, INCLUDING VISION CORRECTION AND SURGERIES.",
      "GOAL OR MAIN AIM: TO MAINTAIN AND RESTORE EYE HEALTH AND VISION, OFFERING ADVANCED DIAGNOSTICS, SURGICAL INTERVENTIONS, AND EYE CARE.",
      "MAJOR SURGERIES: CATARACT SURGERY, LASER EYE SURGERY, RETINAL SURGERY, CORNEAL TRANSPLANT, STRABISMUS SURGERY."
    ],
  },
  {
    name: "DENTISTRY",
    brief: [
      "ABOUT THE DEPARTMENT: SPECIALIZES IN ORAL HEALTHCARE, INCLUDING DIAGNOSIS, TREATMENT, AND PREVENTION OF DENTAL CONDITIONS.",
      "GOAL OR MAIN AIM: TO MAINTAIN ORAL HEALTH, IMPROVE SMILE APPEARANCE, AND PROVIDE DENTAL SOLUTIONS FOR ALL AGES.",
      "MAJOR TREATMENTS: DENTAL CLEANINGS, FILLINGS, ROOT CANALS, DENTAL EXTRACTIONS, ORTHODONTIC TREATMENTS."
    ],
  },
  {
    name: "RADIOLOGY",
    brief: [
      "ABOUT THE DEPARTMENT: SPECIALIZES IN MEDICAL IMAGING TECHNIQUES TO DIAGNOSE AND MONITOR DISEASES AND CONDITIONS THROUGH VARIOUS IMAGING MODALITIES.",
      "GOAL OR MAIN AIM: TO PROVIDE ACCURATE DIAGNOSIS, GUIDING TREATMENT PLANS THROUGH ADVANCED IMAGING TECHNOLOGIES AND TECHNIQUES.",
      "MAJOR IMAGING MODALITIES: X-RAY, CT SCAN, MRI, ULTRASOUND, NUCLEAR MEDICINE, MAMMOGRAPHY, FLUOROSCOPY, PET-CT SCAN."
    ],
  },
  {
    name: "DERMATOLOGY",
    brief: [
      "ABOUT THE DEPARTMENT: SPECIALIZES IN SKIN, HAIR, AND NAIL CONDITIONS, INCLUDING DIAGNOSIS, TREATMENT, AND COSMETIC PROCEDURES.",
      "GOAL OR MAIN AIM: TO PROVIDE SKIN HEALTHCARE, ADDRESSING MEDICAL AND COSMETIC CONCERNS WHILE PROMOTING SKIN WELLNESS.",
      "MAJOR TREATMENTS: SKIN CANCER SCREENING, ACNE TREATMENT, COSMETIC DERMATOLOGY, PSORIASIS MANAGEMENT, MOLE REMOVAL."
    ],
  },
  {
    name: "PEDIATRIC",
    brief: [
      "ABOUT THE DEPARTMENT: FOCUSES ON MEDICAL CARE SPECIFICALLY FOR CHILDREN, INCLUDING DIAGNOSIS, TREATMENT, AND WELLNESS CHECKS.",
      "GOAL OR MAIN AIM: TO ENSURE CHILDREN'S HEALTH AND WELLBEING, PROVIDING PEDIATRIC MEDICAL SERVICES FROM INFANCY TO ADOLESCENCE.",
      "MAJOR TREATMENTS: CHILDHOOD VACCINATIONS, PEDIATRIC WELLNESS EXAMS, COMMON ILLNESS TREATMENTS, GROWTH MONITORING."
    ],
  },
  {
    name: "GYNAECOLOGY",
    brief: [
      "ABOUT THE DEPARTMENT: SPECIALIZES IN WOMEN'S REPRODUCTIVE HEALTH, INCLUDING DIAGNOSIS, TREATMENT, AND SURGICAL INTERVENTIONS.",
      "GOAL OR MAIN AIM: TO PROVIDE COMPREHENSIVE CARE FOR WOMEN'S REPRODUCTIVE NEEDS, INCLUDING GYNAECOLOGICAL AND OBSTETRIC CARE.",
      "MAJOR SURGERIES: HYSTERECTOMY, CESAREAN SECTION, FIBROID REMOVAL, LAPAROSCOPIC SURGERY, ENDOMETRIAL ABLATION."
    ],
  },
];

function Treatments() {
  // State variables for the selected speciality and modal visibility
  const [selectedSpeciality, setSelectedSpeciality] = useState(null);
  const [showModal, setShowModal] = useState(false);

  // Function to handle clicking on a speciality container
  const handleSpecialityClick = (speciality) => {
    setSelectedSpeciality(speciality);
    setShowModal(true);
  };

  // Function to handle closing the modal
  const handleModalClose = () => {
    setSelectedSpeciality(null);
    setShowModal(false);
  };

  return (
    <div className="treatments"> {/* Container for the entire Treatments component */}
      {specialities.map((speciality) => (
        // Mapping over the specialities array to generate speciality containers
        <div
          key={speciality.name}
          className={`speciality-container ${
            selectedSpeciality === speciality ? "active" : ""
          }`}
          onClick={() => handleSpecialityClick(speciality)} // Click handler for the speciality container
        >
          <h2>{speciality.name}</h2> {/* Displaying the speciality name */}
          <div className="diet-buttons">
            <button className="diet-button">VIEW MORE</button>
          </div>
        </div>
      ))}
      {/* Modal overlay that displays information about the selected speciality */}
      {showModal && (
        <div className="modal-overlay active">
          <div className="modal-content">
            <h2>{selectedSpeciality.name}</h2> {/* Displaying the speciality name in the modal */}
            {selectedSpeciality.brief.map((paragraph, index) => (
              // Mapping over the brief array of the selected speciality
              <p key={index}>{paragraph}</p> 
            ))}
            <button className="done-button" onClick={handleModalClose}>
              DONE
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default Treatments; // Exporting the Treatments component as the default export