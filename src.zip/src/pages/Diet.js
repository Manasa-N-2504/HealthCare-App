import React, { useState } from "react"; // Importing React and the useState hook
import dietBackground from "../assets/diet_background.png"; // Importing the background image
import "../styles/Diet.css"; // Importing a CSS file for styling

// Array of objects containing information about different age groups and their dietary recommendations
const ageGroups = [
  {
    title: "INFANTS (0-1 YEAR)",
    content:
      "BREAST MILK OR FORMULA IS THE PRIMARY SOURCE OF NUTRITION FOR INFANTS. IT PROVIDES ESSENTIAL NUTRIENTS AND ANTIBODIES FOR OPTIMAL GROWTH AND DEVELOPMENT. AROUND 6 MONTHS OF AGE, YOU CAN START INTRODUCING SOLID FOODS TO COMPLEMENT THEIR MILK INTAKE. BEGIN WITH IRON-FORTIFIED CEREALS, PUREED FRUITS, AND VEGETABLES. THESE FOODS PROVIDE ADDITIONAL NUTRIENTS LIKE IRON, WHICH IS CRUCIAL FOR BRAIN DEVELOPMENT AND PREVENTING ANEMIA. AVOID ADDING SUGARS, SALT, AND HONEY TO YOUR INFANT'S DIET DURING THE FIRST YEAR, AS THEIR DELICATE DIGESTIVE SYSTEMS ARE NOT READY TO HANDLE THESE SUBSTANCES."
  },
  {
    title: "TODDLERS AND PRESCHOOLERS (1-5 YEARS)",
    content:
      "DURING THIS PHASE, IT'S IMPORTANT TO OFFER A VARIETY OF NUTRIENT-DENSE FOODS TO SUPPORT THEIR RAPID GROWTH AND DEVELOPMENT. INCLUDE FOODS FROM ALL FOOD GROUPS: FRUITS, VEGETABLES, WHOLE GRAINS, LEAN PROTEINS, AND DAIRY. LIMIT SUGARY SNACKS, JUICES, AND PROCESSED FOODS TO PREVENT EXCESSIVE SUGAR INTAKE AND ESTABLISH HEALTHY EATING HABITS. ENCOURAGE SELF-FEEDING AND TEACH THEM ABOUT DIFFERENT FOODS. BE CAUTIOUS OF CHOKING HAZARDS AND CUT FOODS INTO APPROPRIATE SIZES TO ENSURE SAFETY."
  },
  {
    title: "CHILDREN AND ADOLESCENTS (6-18 YEARS)",
    content:
      "NUTRITION PLAYS A SIGNIFICANT ROLE IN SHAPING LONG-TERM HEALTH DURING THIS STAGE. FOCUS ON NUTRIENT-DENSE FOODS LIKE WHOLE GRAINS, LEAN PROTEINS, FRUITS, AND VEGETABLES. ENCOURAGE WATER CONSUMPTION AND WHOLE FRUITS INSTEAD OF SUGARY DRINKS AND SNACKS. TEACH PORTION CONTROL AND MINDFUL EATING TO HELP PREVENT OVEREATING. ENGAGE KIDS IN MEAL PLANNING AND PREPARATION TO FOSTER A HEALTHY RELATIONSHIP WITH FOOD AND DEVELOP LIFELONG COOKING SKILLS."
  },
  {
    title: "YOUNG ADULTS (19-30 YEARS)",
    content:
      "MAINTAIN A BALANCED DIET THAT INCLUDES A VARIETY OF NUTRIENT-RICH FOODS. CONSUME WHOLE GRAINS, LEAN PROTEINS, FRUITS, AND VEGETABLES TO PROVIDE YOUR BODY WITH ESSENTIAL VITAMINS AND MINERALS. BE MINDFUL OF PORTION SIZES TO PREVENT OVEREATING AND UNNECESSARY WEIGHT GAIN. MINIMIZE INTAKE OF PROCESSED FOODS, SUGARY SNACKS, AND FAST FOOD TO SUPPORT OVERALL HEALTH. OPT FOR WATER AS YOUR PRIMARY BEVERAGE AND LIMIT SUGARY DRINKS TO REDUCE EXCESS SUGAR CONSUMPTION."
  },
  {
    title: "ADULTS (31-50 YEARS)",
    content:
      "CONTINUE PRIORITIZING A BALANCED DIET THAT INCLUDES WHOLE GRAINS, LEAN PROTEINS, FRUITS, AND VEGETABLES. PAY ATTENTION TO YOUR CALORIE INTAKE AND ADJUST IT BASED ON POTENTIAL CHANGES IN METABOLISM AS YOU AGE. INCORPORATE SOURCES OF HEALTHY FATS, SUCH AS AVOCADOS, NUTS, AND OLIVE OIL, WHICH PROVIDE ESSENTIAL FATTY ACIDS FOR HEART HEALTH. LIMIT ALCOHOL CONSUMPTION AND AVOID SMOKING TO REDUCE HEALTH RISKS."
  },
  {
    title: "MIDDLE-AGED ADULTS (51-70 YEARS)",
    content:
      "FOCUS ON FOODS RICH IN CALCIUM AND VITAMIN D TO MAINTAIN STRONG BONES AND PREVENT BONE DENSITY LOSS. INCREASE YOUR INTAKE OF FIBER-RICH FOODS LIKE WHOLE GRAINS, FRUITS, AND VEGETABLES TO SUPPORT DIGESTION AND PREVENT CONSTIPATION. DUE TO POTENTIAL METABOLIC CHANGES, CONSIDER ADJUSTING YOUR CALORIE INTAKE TO AVOID WEIGHT GAIN."
  },
  {
    title: "OLDER ADULTS (70+ YEARS)",
    content:
      "MAINTAIN A NUTRIENT-RICH DIET THAT SUPPORTS IMMUNE FUNCTION AND OVER ALL HEALTH. ADEQUATE PROTEIN INTAKE IS ESSENTIAL FOR PRESERVING MUSCLE MASS AND PREVENTING AGE-RELATED MUSCLE LOSS. STAY HYDRATED AND MONITOR FLUID INTAKE, AS THE SENSATION OF THIRST CAN DECREASE WITH AGE, LEADING TO DEHYDRATION. BE CAUTIOUS OF POTENTIAL FOOD INTERACTIONS WITH MEDICATIONS YOU MIGHT BE TAKING."
  },
];

function Diet() {
  // State variable to track the selected age group
  const [selectedAgeGroup, setSelectedAgeGroup] = useState(null);

  return (
    <div className="diet"> {/* Container for the entire Diet component */}
      {/* Mapping over the ageGroups array to generate age group containers */}
      {ageGroups.map((ageGroup) => (
        <div
          key={ageGroup.title}
          className={`diet-container ${
            selectedAgeGroup === ageGroup ? "active" : ""
          }`}
          onClick={() => setSelectedAgeGroup(ageGroup)} // Click handler for the age group container
        >
          <h2>{ageGroup.title}</h2> {/* Displaying the age group title */}
          <div className="diet-buttons">
            <button className="diet-button">VIEW DIET CHART</button> {/* Button to view diet chart */}
          </div>
        </div>
      ))}
      {/* Modal overlay that displays information about the selected age group */}
      {selectedAgeGroup && (
        <div className="modal-overlay active">
          <div className="modal-content">
            <h2>{selectedAgeGroup.title}</h2> {/* Displaying the selected age group title */}
            <p>{selectedAgeGroup.content}</p> {/* Displaying the content about dietary recommendations */}
            <button className="done-button" onClick={() => setSelectedAgeGroup(null)}>
              Done
            </button>
          </div>
        </div>
      )}
      {/* Container for additional buttons */}
      <div className="diet-button-container">
        <a href="/appointment" className="contact-button">
          CONTACT US
        </a>
        <a href="/contact" className="contact-button">
          QUERIES
        </a>
      </div>
    </div>
  );
}

export default Diet; // Exporting the Diet component as the default export