import React from "react"; // Importing the React library
import BannerImage from "../assets/about.png"; // Importing an image file
import "../styles/About.css"; // Importing a CSS file for styling

function About() {
  return (
    <div
      className="about" // Applying the "about" class for styling
      style={{ backgroundImage: `url(${BannerImage})`, backgroundColor: '#0000' }} // Adding inline styles to set the background image and color
    >
      <div className="about-content-container"> {/* A container for the content */}
        <h1> ABOUT US </h1> {/* A heading */}
        <p>
          MAX HEALTHCARE IS A PREMIER HEALTHCARE INSTITUTION THAT STANDS AS A
          BEACON OF EXCELLENCE IN THE INDIAN MEDICAL LANDSCAPE. SINCE ITS
          INCEPTION, MAX HEALTHCARE HAS CONSISTENTLY EXEMPLIFIED A COMMITMENT
          TO PROVIDING CUTTING-EDGE MEDICAL SERVICES, COMPASSIONATE PATIENT
          CARE, AND INNOVATIVE HEALTHCARE SOLUTIONS.
        </p> {/* A paragraph of text */}
        <p>
          HEADQUARTERED IN NEW DELHI, MAX HEALTHCARE OPERATES A NETWORK OF
          WORLD-CLASS HOSPITALS STRATEGICALLY LOCATED ACROSS MAJOR CITIES IN
          INDIA. THESE HOSPITALS ARE EQUIPPED WITH STATE-OF-THE-ART
          INFRASTRUCTURE, ADVANCED MEDICAL EQUIPMENT, AND A DIVERSE RANGE OF
          MEDICAL SPECIALTIES, ENSURING THAT PATIENTS HAVE ACCESS TO
          COMPREHENSIVE HEALTHCARE UNDER ONE ROOF.
        </p> {/* Another paragraph of text */}
      </div>
    </div>
  );
}

export default About; // Exporting the About component as the default export
