import React from "react";
import "../styles/Footer.css";

function Footer() {
  return (
    <div className="footer">
      <div className="socialMedia">
        <span className="material-icons">&#xe87d;</span> {/* Instagram */}
        <span className="material-icons">&#xe0a0;</span> {/* Twitter */}
        <span className="material-icons">&#xe90d;</span> {/* Facebook */}
        <span className="material-icons">&#xe8f1;</span> {/* LinkedIn */}
      </div>
    </div>
  );
}

export default Footer;
