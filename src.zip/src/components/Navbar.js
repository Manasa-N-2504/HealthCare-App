import React, { useState } from "react";
import Logo from "../assets/Logo.png";
import { Link } from "react-router-dom";
import "../styles/Navbar.css";

function Navbar() {
  const [openLinks] = useState(false);


  return (
    <div className="navbar">
      <div className="leftSide" id={openLinks ? "open" : "close"}>
        <img src={Logo} />
      </div>
      <div className="rightSide">
        <Link to="/"> HOME </Link>
        <Link to="/appointment"> APPOINTMENT </Link>
        <Link to="/about"> ABOUT US </Link>
        <Link to="/treatment"> TREATMENTS </Link>
        <Link to="/diet"> DIET </Link>
        <Link to="/contact"> QUERIES </Link>
      </div>
    </div>
  );
}

export default Navbar;
